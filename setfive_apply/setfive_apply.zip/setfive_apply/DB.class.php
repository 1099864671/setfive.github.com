<?php 

class DB {
	
	private $configArray;
	private $pdo = null;
	private $lastInsertId = null;
	
	public function __construct(array $configArray){
		$this->configArray = $configArray;
	}
	
	/**
	 * Returns the current PDO connection. Will create it if it doesn't exist.
	 * Uses this->configArray for configuration parameters.
	 * @return PDO
	 */
	public function getConnection(){

	}
	
	/**
	 * Inserts a row into $TABLE with data from $dataArray.
	 * $dataArray is an associative array containing column name => value, assume column names and table is safe.
	 * Also, sets the lastInsertId with the autoincrement value for the created row
	 * @param string $table
	 * @param array $dataArray
	 * @return DB
	 */
	public function insertRow($table, array $dataArray){
				
	}
	
	/**
	 * Performs a SQL UPDATE using whereArray (columnName => value) 
	 * to set dataArray (columnName => value) on $table
	 * @param unknown_type $table
	 * @param array $whereArray
	 * @param array $dataArray
	 * @return DB
	 */
	public function updateRow($table, array $whereArray, array $dataArray){
       	
	}
	
	/**
	 * Inserts several rows into $table. 
	 * $dataArray is assumed to be an array of k => v arrays for the values to insert, assume table and column name values are safe, and consistent across all of the array. 
	 * @param unknown_type $table
	 * @param array $dataArray
	 */
	public function bulkInsertRows($table, array $dataArray){
		
	}
	
	/**
	 * Finds and returns a row by primary key in $table
	 * Returns null if no results are found
	 * @param unknown_type $id
	 */
	public function findById( $table, $id ){
		
	}
	
	/**
	 * Deletes a row in $table with id equal to $id
	 * @param unknown_type $table
	 * @param unknown_type $id
	 */
	public function deleteById( $table, $id ){
		      
	}

	/**
	 * Performs a SELECT * WHERE on $table and returns the rows
	 * $whereArray is assumsed to be a associative array with column name => column value for there WHERE
	 * NOTE: You'll want to use PDO::FETCH_ASSOC truuuust me
	 * @return array
	 */	
	public function selectWhere($table, array $whereArray){
		
	}
	
	/**
	 * Returns the $this->lastInsertId value
	 */
	public function getLastInsertId(){
      
	}
}
