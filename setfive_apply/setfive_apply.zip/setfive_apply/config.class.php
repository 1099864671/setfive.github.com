<?php

class Config
{
    public static $dsn = 'mysql:dbname=setfive_apply';
    public static $username = 'root';
    public static $password = 'root';

}
